-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2021 at 08:40 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `name` varchar(20) NOT NULL,
  `areYouPresent` varchar(20) NOT NULL,
  `workingHours` int(10) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`name`, `areYouPresent`, `workingHours`, `date`) VALUES
('Ayushi', 'ABSENT', 4, 'Sat Sep 04 14:01:46 IST 2021'),
('Ayushi', 'ABSENT', 5, 'Wed Sep 08 00:00:00 IST 2021'),
('Ayushi', 'PRESENT', 10, 'Thu Sep 09 20:48:08 IST 2021'),
('Vansh ', 'PRESENT', 5, 'Wed Sep 08 11:22:51 IST 2021'),
('Vanshika', 'PRESENT', 5, 'Tue Sep 07 19:24:56 IST 2021'),
('nikita', 'PRESENT', 8, 'Fri Oct 01 11:45:15 IST 2021'),
('', 'PRESENT', 8, 'Fri Oct 01 11:45:15 IST 2021');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `name` varchar(20) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `roomtype` varchar(20) NOT NULL,
  `occupancy` varchar(20) NOT NULL,
  `balcony` varchar(20) NOT NULL,
  `date` varchar(100) NOT NULL,
  `days` int(11) NOT NULL,
  `roomnumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`name`, `phoneNumber`, `roomtype`, `occupancy`, `balcony`, `date`, `days`, `roomnumber`) VALUES
('dgfdyf', '4654656', 'SUPERIOR', 'SINGLE', 'YES', 'null', 6, 3),
('', '', 'SUPERIOR', 'SINGLE', 'YES', 'Thu Sep 02', 0, 0),
('fawf', '', 'SUPERIOR', 'SINGLE', 'NO', 'Wed Sep 01', 0, 0),
('dsE', '', 'SUPERIOR', 'SINGLE', 'NO', 'Tue Sep 07 23:09:44 IST 2021', 0, 0),
('rsrrtr', '', 'SUPERIOR', 'SINGLE', 'NO', 'Thu Sep 09 20:01:19 IST 2021', 0, 0),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 6, 0),
('cdfsd', '', 'SUPERIOR', 'SINGLE', 'NO', 'Thu Sep 09 23:08:20 IST 2021', 12, 0),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 12, 0),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 11, 0),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 11, 0),
('dtrhd', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 11, 0),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 12, 0),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 11, 0),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 11, 0),
('ayushi', '123456', 'SUPERIOR', 'SINGLE', 'YES', 'Sat Sep 11 08:08:37 IST 2021', 1, 14),
('xaas', '2543', 'SUPERIOR', 'SINGLE', 'NO', 'null', 0, 14),
('dsedw', '24', 'LUXURY', 'SINGLE', 'NO', 'null', 0, 12),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 0, 11),
('dqwd', '284', 'SUPERIOR', 'SINGLE', 'NO', 'Thu Sep 23 08:15:32 IST 2021', 0, 12),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 0, 12),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 0, 12),
('fes', 'a', 'SUPERIOR', 'SINGLE', 'NO', 'null', 0, 11),
('', '', 'SUPERIOR', 'SINGLE', 'NO', 'null', 0, 11),
('Yashita', '756516', 'PREMIUM', 'QUAD ROOM', 'YES', 'Thu Sep 16 10:13:44 IST 2021', 2, 15),
('egghtht', '1254585', 'LUXURY', 'DOUBLE ROOM ', 'YES', 'Wed Sep 08 00:00:00 IST 2021', 6, 45),
('', '', 'LUXURY', 'TRIPLE ROOM', 'NO', 'null', 0, 0),
('', '', 'SUPERIOR', 'DOUBLE ROOM ', 'NO', 'null', 0, 0),
('nikita', '123567891', 'PREMIUM', 'DOUBLE ROOM ', 'YES', 'Tue Feb 02 12:00:45 IST 2021', 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `name` varchar(20) NOT NULL,
  `age` int(2) NOT NULL,
  `dateofjoining` varchar(20) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `salary` int(11) NOT NULL,
  `password` varchar(20) NOT NULL,
  `workinghours` int(11) NOT NULL,
  `phonenumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login2`
--

CREATE TABLE `login2` (
  `name` varchar(20) NOT NULL,
  `age` int(20) NOT NULL,
  `dateOfJoining` varchar(100) NOT NULL,
  `qualification` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `salary` int(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `workingHours` int(10) NOT NULL,
  `PhoneNumber` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login2`
--

INSERT INTO `login2` (`name`, `age`, `dateOfJoining`, `qualification`, `gender`, `salary`, `password`, `workingHours`, `PhoneNumber`) VALUES
('gdrg', 0, 'null', '', '', 0, '', 12, 0),
('Ayushi', 19, 'Mon Feb 18 11:59:26 IST 2002', 'btech ', 'FEMALE', 0, 'Ayushi@181', 7, 7984779448),
('', 0, 'null', '', '', 0, '', 12, 7984779448),
('Vansh', 18, 'Tue Sep 07 00:00:00 IST 2021', 'Btech running', 'MALE', 1000, 'Vansh@', 4, 1654615),
('Vanshika', 18, 'Tue Sep 07 19:22:33 IST 2021', 'Btech', 'FEMALE', 300, 'qwerty123', 4, 123456789);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `roomNumber` int(20) NOT NULL,
  `roomType` varchar(20) NOT NULL,
  `Occupancy` varchar(20) NOT NULL,
  `balcony` varchar(10) NOT NULL,
  `bookingStatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`roomNumber`, `roomType`, `Occupancy`, `balcony`, `bookingStatus`) VALUES
(7, 'LUXURY', 'DOUBLE ROOM', '0', ''),
(5, 'SUPERIOR ', 'SINGLE ROOM', '0', 'UNBOOKED'),
(4, 'PREMIUM', 'DOUBLE ROOM', '0', 'UNBOOKED'),
(5, 'SUPERIOR ', 'SINGLE ROOM', 'YES', 'UNBOOKED'),
(6, 'PREMIUM', 'QUAD ROOM', 'YES', 'BOOKED'),
(10, 'PREMIUM', 'DOUBLE ROOM', 'YES', 'UNBOOKED'),
(11, 'SUPERIOR ', 'SINGLE ROOM', 'NO', 'BOOKED'),
(12, 'SUPERIOR ', 'SINGLE ROOM', 'NO', 'BOOKED'),
(14, 'PREMIUM', 'DOUBLE ROOM', 'NO', 'BOOKED'),
(15, 'PREMIUM', 'QUAD ROOM', 'YES', 'BOOKED'),
(17, 'SUPERIOR ', 'QUAD ROOM', 'NO', 'UNBOOKED'),
(18, 'LUXURY', 'QUAD ROOM', 'YES', 'UNBOOKED'),
(20, 'LUXURY', 'DOUBLE ROOM', 'YES', 'UNBOOKED'),
(45, 'LUXURY', 'DOUBLE ROOM', 'YES', 'BOOKED');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
